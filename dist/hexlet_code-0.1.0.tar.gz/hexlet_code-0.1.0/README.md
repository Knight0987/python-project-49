### Hexlet tests and linter status:
[![Actions Status](https://github.com/Knight0987/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Knight0987/python-project-49/actions)

https://asciinema.org/a/Zxlh15sx8e1HKpThgfp9GhHzF
https://asciinema.org/a/8jW29zg3z7Si5pG0vyauw4hkJ
https://asciinema.org/a/FhMJvJAGGV373alDZh06lybmc
