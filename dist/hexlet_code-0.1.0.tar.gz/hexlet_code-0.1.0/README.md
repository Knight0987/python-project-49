### Hexlet tests and linter status:
[![Actions Status](https://github.com/Knight0987/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Knight0987/python-project-49/actions)

https://asciinema.org/a/Zxlh15sx8e1HKpThgfp9GhHzF
